package manojveluru.niu.imagegallery;

public class Character
{
    private String characterDescription;
    private int characterID;

    public Character(String Description, int ID)
    {
        characterDescription = Description;
        characterID = ID;
    }

    public String getCharacterDescription() {
        return characterDescription;
    }

    public void setCharacterDescription(String description) {
        characterDescription = description;
    }

    public int getCharacterID() {
        return characterID;
    }

    public void setCharacterID(int newID) {
        characterID = newID;
    }
}
