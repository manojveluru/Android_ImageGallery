package manojveluru.niu.imagegallery;

public class CharacterInfo
{
    public static String description[] = { "Johnny Bravo\nHey 911 there's a handsome guy in my house! Oh wait, it's only me.",
            "Stewie Griffin\nVictory is mine!",
            "Fred Flintstone\nYabba Dabba Dooo!",
            "Angelica Pickles\nYou dumb babies!",
            "George Jetson\nYum, it's been lightyears since you programmed synthetic brownies.",
            "Velma Dinkley\nJinkies"};

    public static int id[] = {R.drawable.character1, R.drawable.character2, R.drawable.character3,
                                R.drawable.character4,R.drawable.character5,R.drawable.character6};
}
